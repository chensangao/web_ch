<?php
global $allmodules;
$GLOBALS['allmodules']['1f35620fb42d452fa2bdc1dee1690f92']='1f35620fb42d452fa2bdc1dee1690f92.xml';
$GLOBALS['allmodules']['72ffa6fabe3c236f9238a2b281bc0f93']='72ffa6fabe3c236f9238a2b281bc0f93.xml';
$GLOBALS['allmodules']['8d34b452d72fd265e6862526c87bf55a']='8d34b452d72fd265e6862526c87bf55a.xml';
$GLOBALS['allmodules']['b437d85a7a7bc778c9c79b5ec36ab9aa']='b437d85a7a7bc778c9c79b5ec36ab9aa.xml';
?>